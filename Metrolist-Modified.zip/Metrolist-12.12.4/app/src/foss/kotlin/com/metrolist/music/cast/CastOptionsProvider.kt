package com.metrolist.music.cast

/**
 * Stub CastOptionsProvider for F-Droid builds.
 * The AndroidManifest reference is removed via manifest merger.
 */
class CastOptionsProvider
