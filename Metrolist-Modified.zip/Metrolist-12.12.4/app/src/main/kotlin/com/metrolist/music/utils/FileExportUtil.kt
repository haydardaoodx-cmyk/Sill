/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.utils

import android.content.Context
import android.os.Environment
import androidx.media3.datasource.cache.SimpleCache
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.LyricsEntity
import com.metrolist.music.di.DownloadCache
import com.metrolist.music.lyrics.LyricsHelper
import com.metrolist.music.models.toMediaMetadata
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FileExportUtil @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: MusicDatabase,
    private val lyricsHelper: LyricsHelper,
    @DownloadCache private val downloadCache: SimpleCache
) {
    private val logTag = "FileExportUtil"

    /**
     * Exports a downloaded song to the public Music directory.
     * Includes thumbnail and lyrics if available.
     */
    suspend fun exportSong(songId: String) = withContext(Dispatchers.IO) {
        try {
            val song = database.getSongById(songId) ?: return@withContext
            val format = database.getFormatById(songId) ?: return@withContext
            
            val musicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "music")
            if (!musicDir.exists()) {
                musicDir.mkdirs()
            }

            // Sanitize filename
            val baseFileName = "${song.song.title} - ${song.artists.joinToString(", ") { it.name }}".replace(Regex("[\\\\/:*?\"<>|]"), "_")
            
            // 1. Export Music File
            val extension = if (format.mimeType.contains("opus")) "opus" else "m4a"
            val musicFile = File(musicDir, "$baseFileName.$extension")
            
            val cachedFile = getCachedFile(songId)
            if (cachedFile != null && cachedFile.exists()) {
                cachedFile.copyTo(musicFile, overwrite = true)
                Timber.tag(logTag).d("Exported music: ${musicFile.absolutePath}")
            } else {
                Timber.tag(logTag).w("Cached file not found for song: $songId")
            }

            // 2. Export Thumbnail
            song.song.thumbnailUrl?.let { url ->
                val thumbFile = File(musicDir, "$baseFileName.jpg")
                try {
                    URL(url).openStream().use { input ->
                        FileOutputStream(thumbFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    Timber.tag(logTag).d("Exported thumbnail: ${thumbFile.absolutePath}")
                } catch (e: Exception) {
                    Timber.tag(logTag).e(e, "Failed to export thumbnail")
                }
            }

            // 3. Export Lyrics
            var lyrics = database.getLyricsById(songId)
            if (lyrics == null || lyrics.lyrics == LyricsEntity.LYRICS_NOT_FOUND) {
                // Try fetching lyrics if not in DB
                try {
                    val lyricsWithProvider = lyricsHelper.getLyrics(song.toMediaMetadata())
                    if (lyricsWithProvider.lyrics != LyricsEntity.LYRICS_NOT_FOUND) {
                        lyrics = LyricsEntity(songId, lyricsWithProvider.lyrics, lyricsWithProvider.provider)
                        // Save to DB for future use
                        database.query { upsert(lyrics!!) }
                    }
                } catch (e: Exception) {
                    Timber.tag(logTag).e(e, "Failed to fetch lyrics for export")
                }
            }

            if (lyrics != null && lyrics.lyrics != LyricsEntity.LYRICS_NOT_FOUND) {
                val lrcFile = File(musicDir, "$baseFileName.lrc")
                lrcFile.writeText(lyrics.lyrics)
                Timber.tag(logTag).d("Exported lyrics: ${lrcFile.absolutePath}")
            }

        } catch (e: Exception) {
            Timber.tag(logTag).e(e, "Error exporting song: $songId")
        }
    }

    /**
     * Exports all songs currently marked as downloaded in the database.
     */
    suspend fun exportAllDownloadedSongs() = withContext(Dispatchers.IO) {
        try {
            val downloadedSongs = database.getDownloadedSongs()
            Timber.tag(logTag).d("Exporting ${downloadedSongs.size} downloaded songs")
            downloadedSongs.forEach { song ->
                exportSong(song.id)
            }
        } catch (e: Exception) {
            Timber.tag(logTag).e(e, "Error exporting all downloaded songs")
        }
    }

    private fun getCachedFile(songId: String): File? {
        val cachedSpans = downloadCache.getCachedSpans(songId).sortedBy { it.position }
        if (cachedSpans.isEmpty()) return null
        
        // If it's a single file, return it
        if (cachedSpans.size == 1) return cachedSpans.first().file

        // If multiple spans, we should ideally merge them.
        // For simplicity in this edit, we'll try to find the largest span or the first one.
        // In a production app, we'd use a CacheDataSource to read the entire stream and write to the destination.
        return cachedSpans.maxByOrNull { it.length }?.file
    }
}
