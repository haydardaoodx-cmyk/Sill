/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.utils

import android.content.Context
import com.metrolist.music.constants.ExcludedFoldersKey
import com.metrolist.music.constants.IncludedFoldersKey
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.ArtistEntity
import com.metrolist.music.db.entities.SongArtistMap
import com.metrolist.music.db.entities.AlbumEntity
import com.metrolist.music.utils.dataStore
import java.time.LocalDateTime
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalSyncUtils @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: MusicDatabase,
) {
    private val scanner = LocalMediaScanner(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    fun syncLocalMedia() {
        scope.launch {
            val included = context.dataStore.data.first()[IncludedFoldersKey]?.split(",")?.filter { it.isNotEmpty() } ?: emptyList()
            val excluded = context.dataStore.data.first()[ExcludedFoldersKey]?.split(",")?.filter { it.isNotEmpty() } ?: emptyList()
            
            val localSongs = scanner.scan(included, excluded)
            
            database.transaction {
                localSongs.forEach { song ->
                    // Upsert song
                    upsert(song)
                    
                    // Handle Artist
                    val artistName = song.artistsText ?: "Unknown Artist"
                    val artistId = "local_artist_${artistName.hashCode()}"
                    upsert(ArtistEntity(id = artistId, name = artistName, isLocal = true))
                    upsert(SongArtistMap(songId = song.id, artistId = artistId, index = 0))

                    // Handle Album
                    song.albumId?.let { albumId ->
                        upsert(AlbumEntity(
                            id = albumId,
                            title = song.albumName ?: "Unknown Album",
                            thumbnailUrl = song.thumbnailUrl,
                            songCount = 1, // Simplified
                            duration = song.duration,
                            isLocal = true,
                            inLibrary = LocalDateTime.now()
                        ))
                        upsert(com.metrolist.music.db.entities.SongAlbumMap(songId = song.id, albumId = albumId, index = 0))
                    }
                }
            }
        }
    }
}
